<div class="player-wrapper">
	<h1>About</h1>
	<iframe width="80%" height="500" src="//www.youtube.com/embed/BvxoSd7k9bU?autoplay=0&showinfo=0&rel=0" frameborder="0" allowfullscreen></iframe>
	<iframe width="80%" height="500" src="//www.youtube.com/embed/I-evxZ-FZpk?autoplay=0&showinfo=0&rel=0" frameborder="0" allowfullscreen></iframe>
	<h1>Shalhavit's Welcome!</h1>
	<iframe width="80%" height="500" src="//www.youtube.com/embed/40U--bTL93s?autoplay=0&showinfo=0&rel=0" frameborder="0" allowfullscreen></iframe>
</div>